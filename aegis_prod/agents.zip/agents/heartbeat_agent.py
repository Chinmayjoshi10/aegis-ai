from aegis_ai.core.agent_base import Agent
from aegis_ai.agents.janitor_agent import JanitorAgent

class HeartbeatAgent(Agent):
    def __init__(self):
        super().__init__("Heartbeat")

    def run(self, state):
        state["kernel_alive"] = True

        # Temporal decay of stale semantic memory
        if "pg" in state:
            JanitorAgent(state["pg"]).decay(minutes=10)

        return state
