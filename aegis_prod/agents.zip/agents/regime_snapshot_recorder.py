from typing import Dict, Any
from copy import deepcopy
from datetime import datetime


class RegimeSnapshotRecorder:
    """
    Layer 3 enabler.

    Persists regime-scoped cognitive snapshots so that
    future agents can compare behavior across regimes.

    - No insights
    - No ML
    - No mutation of existing intelligence
    """

    def run(self, state: Dict[str, Any]) -> None:
        intelligence = state.get("intelligence", {})
        regime = intelligence.get("regime")

        if not regime:
            return

        snapshot = {
            "timestamp": datetime.utcnow().isoformat(),
            "regime": deepcopy(regime),
            "intelligence": deepcopy(intelligence),
        }

        history = intelligence.setdefault("regime_history", [])
        history.append(snapshot)

        # Hard cap to prevent unbounded growth (V1-safe)
        if len(history) > 50:
            del history[:-50]
