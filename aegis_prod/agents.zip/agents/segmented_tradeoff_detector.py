from typing import Dict, Any


class SegmentedTradeoffDetector:
    """
    Layer 3 — Segmented Tradeoff Detection.
    Emits insight ONLY if tradeoff behavior differs across regimes.
    """

    def run(self, state: Dict[str, Any]) -> None:
        intelligence = state.get("intelligence", {})
        history = intelligence.get("regime_history")

        if not history or len(history) < 2:
            return

        tradeoffs_by_regime = {}

        for entry in history:
            regime = entry.get("regime")
            intel = entry.get("intelligence", {})
            tradeoffs = intel.get("tradeoffs")

            if not tradeoffs:
                continue

            key = f"{regime['load']}|{regime['stress']}"
            tradeoffs_by_regime.setdefault(key, []).append(tradeoffs)

        if len(tradeoffs_by_regime) < 2:
            return

        regimes = list(tradeoffs_by_regime.keys())
        base_key = regimes[0]
        base_tradeoffs = tradeoffs_by_regime[base_key][-1]

        for other_key in regimes[1:]:
            other_tradeoffs = tradeoffs_by_regime[other_key][-1]

            if base_tradeoffs != other_tradeoffs:
                intelligence.setdefault("insights", []).append({
                    "type": "SEGMENTED_TRADEOFF",
                    "from_regime": base_key,
                    "to_regime": other_key,
                    "statement": "Tradeoff behavior differs across operating regimes",
                })
                return
