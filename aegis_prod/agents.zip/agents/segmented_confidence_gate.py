from typing import Dict, Any


class SegmentedConfidenceGate:
    """
    Layer 4 (V1): Confidence gating for segmented insights.

    Rules:
    - Insights without sufficient evidence are removed
    - No new insights are created
    - Silence is preserved
    """

    MIN_OCCURRENCES = 2

    def run(self, state: Dict[str, Any]) -> None:
        intelligence = state.get("intelligence", {})
        insights = intelligence.get("insights")

        if not insights:
            return

        history = intelligence.get("regime_history")
        if not history:
            intelligence.pop("insights", None)
            return

        gated = []

        for insight in insights:
            from_regime = insight.get("from_regime")
            to_regime = insight.get("to_regime")

            if not from_regime or not to_regime:
                continue

            from_count = 0
            to_count = 0

            for entry in history:
                regime = entry.get("regime", {})
                key = f"{regime.get('load')}|{regime.get('stress')}"

                if key == from_regime:
                    from_count += 1
                elif key == to_regime:
                    to_count += 1

            if from_count >= self.MIN_OCCURRENCES and to_count >= self.MIN_OCCURRENCES:
                gated.append(insight)

        if gated:
            intelligence["insights"] = gated
        else:
            intelligence.pop("insights", None)
