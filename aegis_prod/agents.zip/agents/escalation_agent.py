from aegis_ai.motor.self_healing_executor import SelfHealingExecutor

class EscalationAgent:
    """
    Executes autonomous remediation when Drift Brain issues a self-healing patch.
    Now protected by Phase-6 Meta-Reasoning Cortex.
    """

    def __init__(self):
        self.executor = SelfHealingExecutor()

    def run(self, state: dict):

        # 🧠 Phase-6 Meta-Reasoning Gate
        meta = state.get("meta_decision", {})
        if meta.get("action") == "SUPPRESS":
            state["self_healing_executed"] = False
            state["escalation"] = "SUPPRESSED_BY_META_REASONING"
            return state

        drift = state.get("drift_report", {})

        # Execute self-healing patch only if cognition allows
        patch = drift.get("self_healing_patch")
        if patch:
            try:
                self.executor.execute(patch)
                state["self_healing_executed"] = True
            except Exception as e:
                state["self_healing_error"] = str(e)
                state["self_healing_executed"] = False
        else:
            state["self_healing_executed"] = False

        return state
